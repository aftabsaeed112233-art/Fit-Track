# FitTrack Android app starter (HTML + Firebase cloud sync)

This is an Android Studio source project, not a compiled APK. The current environment did not have the Android SDK/Gradle build tools needed to compile an APK. You can build it with Android Studio after configuring Firebase.

## What it contains
- Your FitTrack diet, water, activity, weight and reports interface, bundled inside an Android WebView.
- Email/password sign-up and sign-in.
- Firestore cloud storage per user. Sign in on both phones with the same account to sync.

## A. Configure Firebase (one-time)
1. Open https://console.firebase.google.com/ and create a project.
2. In Project settings, add a **Web app** and copy its config.
3. In `app/src/main/assets/index.html`, find `const firebaseConfig` and replace the four `REPLACE_...` values with the matching `apiKey`, `authDomain`, `projectId`, and `appId` from Firebase. Do not paste passwords or service-account private keys into this file.
4. In Firebase Console → Authentication → Sign-in method, enable **Email/Password**.
5. In Firebase Console → Firestore Database, create a database.
6. In Firestore → Rules, use the rules below and publish them. These rules allow each signed-in user to access only their own FitTrack document.

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/appData/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

Firebase web config is intended to be present in client apps; access protection comes from Authentication and Firestore Security Rules. Never add service-account keys.

## B. Build the APK
1. Install Android Studio from https://developer.android.com/studio on a computer.
2. Extract this ZIP. In Android Studio choose **Open** and select the `FitTrackAndroid` folder.
3. Allow Gradle sync and install any requested Android SDK platform (API 35).
4. Connect an Android phone with USB debugging enabled, or use an emulator. Click **Run** to test.
5. To create an installable debug APK, select **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio shows the output location.
6. Copy the APK to your phone and open it. You may need to allow installing unknown apps for the file manager you use.
7. Install the same APK on the second phone. Create/sign in to the same FitTrack email/password account.

## Notes
- First sign-in creates or loads the cloud record. The first phone to initialize a new account seeds the record from its local data.
- Use the same account on both phones. Keep a backup using the app's Export data button.
- This is a starter implementation. Test syncing on both phones before relying on it as the only copy of your records.
- The app loads Firebase's JavaScript SDK from Google's CDN, so internet access is required for sign-in and cloud sync.
