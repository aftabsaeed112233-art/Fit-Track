package com.fittrack.app

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
  private lateinit var webView: WebView
  private lateinit var assetLoader: WebViewAssetLoader
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    assetLoader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
    webView = WebView(this)
    webView.settings.javaScriptEnabled = true
    webView.settings.domStorageEnabled = true
    webView.settings.allowFileAccess = false
    webView.webViewClient = object : WebViewClient() {
      override fun shouldInterceptRequest(view: WebView, url: android.webkit.WebResourceRequest) = assetLoader.shouldInterceptRequest(url.url)
      override fun shouldInterceptRequest(view: WebView, url: String) = assetLoader.shouldInterceptRequest(android.net.Uri.parse(url))
    }
    webView.webChromeClient = WebChromeClient()
    setContentView(webView)
    webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
  }
  @Deprecated("Deprecated in Android")
  override fun onBackPressed() { if (webView.canGoBack()) webView.goBack() else super.onBackPressed() }
}
